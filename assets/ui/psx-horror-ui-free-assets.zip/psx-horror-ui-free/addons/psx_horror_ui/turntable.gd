extends TextureRect
## An item turning in the examine frame: one of `icons/turn/`'s sheets (FRAMES frames, COLUMNS
## across), a frame at a time. It turns by itself; dragging it, or the left and right keys while it
## has focus, turn it by hand, and `rest` seconds later it goes on by itself.
##     var item := preload("res://addons/psx_horror_ui/turntable.gd").new()
##     item.sheet = load("res://addons/psx_horror_ui/icons/turn/pistol.png")

const FRAMES := 24
const COLUMNS := 6

## The item's sheet; null shows `texture`, held still.
@export var sheet: Texture2D:
	set(v):
		sheet = v
		_atlas.atlas = v
		texture = _atlas if v else null
		focus_mode = FOCUS_ALL if v else FOCUS_NONE  # what has no sheet is a still picture
		mouse_default_cursor_shape = CURSOR_DRAG if v else CURSOR_ARROW
		_show()
## Frames a second it turns by itself; 0 holds it still until the player turns it.
@export var speed := 8.0
## Frames a second the keys turn it.
@export var key_speed := 16.0
## Seconds after the player's last turn before it turns by itself again.
@export var rest := 2.0

var frame := 0.0
var _atlas := AtlasTexture.new()
var _idle := INF  # seconds since the player last turned it
var _dragging := false


func _init() -> void:
	focus_mode = FOCUS_NONE
	mouse_filter = MOUSE_FILTER_STOP
	stretch_mode = STRETCH_KEEP_CENTERED


func _process(delta: float) -> void:
	var keys := Input.get_axis(&"ui_left", &"ui_right") if has_focus() else 0.0
	if keys != 0.0:
		turn(keys * key_speed * delta)
	elif _idle >= rest and not _dragging:
		turn(speed * delta, false)
	_idle += delta


## Turns it on by `frames` (a fraction too; back if negative): its front moves right.
func turn(frames: float, by_hand := true) -> void:
	frame = fposmod(frame + frames, FRAMES)
	if by_hand:
		_idle = 0.0
	_show()


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_dragging = event.pressed
		if event.pressed:
			grab_focus()
		accept_event()
	elif event is InputEventMouseMotion and _dragging:
		turn(event.relative.x * FRAMES / 120.0)  # a whole turn every 120 art pixels across
		accept_event()
	elif event.is_action(&"ui_left") or event.is_action(&"ui_right"):
		accept_event()  # the keys turn it rather than move the focus


func _notification(what: int) -> void:
	if what in [NOTIFICATION_FOCUS_ENTER, NOTIFICATION_FOCUS_EXIT, NOTIFICATION_THEME_CHANGED]:
		queue_redraw()


func _draw() -> void:
	if not has_focus() or not has_theme_icon(&"pointer", &"Marks"):
		return
	var mark := get_theme_icon(&"pointer", &"Marks")
	var at := Vector2(size.x - mark.get_width() - 2, floorf((size.y - mark.get_height()) / 2))
	draw_texture(mark, at)
	draw_texture_rect(mark, Rect2(Vector2(2 + mark.get_width(), at.y), Vector2(-mark.get_width(), mark.get_height())), false)


func _show() -> void:
	if sheet == null:
		return
	var side := sheet.get_height() * COLUMNS / FRAMES
	var i := int(frame)
	_atlas.region = Rect2((i % COLUMNS) * side, i / COLUMNS * side, side, side)
